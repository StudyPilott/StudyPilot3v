import React, { useState, useEffect } from "react";
import "./ExamReminders.css";

function getSavedReminders() {
  return JSON.parse(localStorage.getItem("studypilot-reminders") || "[]");
}
function saveReminders(reminders) {
  localStorage.setItem("studypilot-reminders", JSON.stringify(reminders));
}

function requestNotificationPermission() {
  if ("Notification" in window && Notification.permission !== "granted") {
    Notification.requestPermission();
  }
}

function scheduleNotification(reminder) {
  if ("Notification" in window && Notification.permission === "granted") {
    const now = Date.now();
    const target = new Date(reminder.date + "T" + reminder.time).getTime();
    if (target > now) {
      setTimeout(() => {
        new Notification("📚 Study Reminder", {
          body: reminder.title,
          silent: reminder.silent,
        });
      }, target - now);
    }
  }
}

export default function ExamReminders() {
  const [reminders, setReminders] = useState(getSavedReminders());
  const [form, setForm] = useState({
    title: "",
    date: "",
    time: "",
    repeat: "none",
    silent: false,
  });

  useEffect(() => {
    saveReminders(reminders);
    // Schedule notifications for upcoming reminders
    reminders.forEach((r) => {
      if (!r.done) scheduleNotification(r);
    });
  }, [reminders]);

  useEffect(() => {
    requestNotificationPermission();
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.title || !form.date || !form.time) return;
    setReminders([
      ...reminders,
      { ...form, id: Date.now() + Math.random(), done: false },
    ]);
    setForm({
      title: "",
      date: "",
      time: "",
      repeat: "none",
      silent: false,
    });
  };

  const markDone = (id) =>
    setReminders(
      reminders.map((r) => (r.id === id ? { ...r, done: true } : r))
    );

  const deleteReminder = (id) =>
    setReminders(reminders.filter((r) => r.id !== id));

  const reschedule = (id) => {
    const reminder = reminders.find((r) => r.id === id);
    if (!reminder) return;
    const newDate = prompt("New date? (YYYY-MM-DD)", reminder.date);
    const newTime = prompt("New time? (HH:MM, 24hr)", reminder.time);
    if (newDate && newTime) {
      setReminders(
        reminders.map((r) =>
          r.id === id ? { ...r, date: newDate, time: newTime, done: false } : r
        )
      );
    }
  };

  const upcomingReminders = reminders
    .filter((r) => !r.done)
    .sort(
      (a, b) =>
        new Date(a.date + "T" + a.time) - new Date(b.date + "T" + b.time)
    );

  return (
    <div className="examreminders-container">
      <h2>Exam & Study Reminders</h2>
      <form className="reminder-form" onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Reminder title (e.g., Physics Exam, Revise Ch. 3)"
          value={form.title}
          required
          onChange={(e) => setForm({ ...form, title: e.target.value })}
        />
        <input
          type="date"
          value={form.date}
          required
          onChange={(e) => setForm({ ...form, date: e.target.value })}
        />
        <input
          type="time"
          value={form.time}
          required
          onChange={(e) => setForm({ ...form, time: e.target.value })}
        />
        <select
          value={form.repeat}
          onChange={(e) => setForm({ ...form, repeat: e.target.value })}
        >
          <option value="none">No Repeat</option>
          <option value="daily">Daily</option>
          <option value="weekly">Weekly</option>
        </select>
        <label>
          <input
            type="checkbox"
            checked={form.silent}
            onChange={(e) => setForm({ ...form, silent: e.target.checked })}
          />
          Silent
        </label>
        <button type="submit">Add Reminder</button>
      </form>
      <ul className="reminder-list">
        {upcomingReminders.length === 0 && (
          <li className="empty">No upcoming reminders.</li>
        )}
        {upcomingReminders.map((reminder) => (
          <li key={reminder.id} className={reminder.done ? "done" : ""}>
            <div>
              <div className="reminder-title">{reminder.title}</div>
              <div className="reminder-datetime">
                {reminder.date} {reminder.time}
              </div>
              <div className="reminder-repeat">
                {reminder.repeat !== "none" ? `Repeats: ${reminder.repeat}` : ""}
              </div>
              <div className="reminder-mode">
                {reminder.silent ? "Silent" : "Sound"}
              </div>
            </div>
            <div className="reminder-actions">
              <button onClick={() => markDone(reminder.id)}>Done</button>
              <button onClick={() => reschedule(reminder.id)}>Reschedule</button>
              <button onClick={() => deleteReminder(reminder.id)}>Delete</button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}