import React from "react";
import "./Button.css";

export default function Button({ children, onClick, type = "button", ...props }) {
  return (
    <button className="studypilot-btn" onClick={onClick} type={type} {...props}>
      {children}
    </button>
  );
}