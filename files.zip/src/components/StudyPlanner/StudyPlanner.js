import React, { useState, useEffect } from "react";
import "./StudyPlanner.css";

const priorities = [
  { value: "high", label: "High 🔴" },
  { value: "medium", label: "Medium 🟡" },
  { value: "low", label: "Low 🟢" },
];

// Helper to get today's date as YYYY-MM-DD
function getToday() {
  return new Date().toISOString().slice(0, 10);
}

// Helper to get date labels for 7 days (Sun-Sat)
function getWeekDates() {
  const today = new Date();
  const week = [];
  for (let i = -today.getDay(); i < 7 - today.getDay(); i++) {
    const d = new Date(today);
    d.setDate(today.getDate() + i);
    week.push(d.toISOString().slice(0, 10));
  }
  return week;
}

export default function StudyPlanner() {
  const [tasks, setTasks] = useState({});
  const [form, setForm] = useState({ subject: "", topic: "", priority: "medium" });
  const [selectedDay, setSelectedDay] = useState(getToday());

  // Load from localStorage
  useEffect(() => {
    const data = JSON.parse(localStorage.getItem("studyplanner-tasks")) || {};
    setTasks(data);

    // Carry forward logic: moves unfinished tasks from yesterday to today, once per day
    const lastCarry = localStorage.getItem("studyplanner-carry") || "";
    if (lastCarry !== getToday()) {
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const yday = yesterday.toISOString().slice(0, 10);
      if (data[yday]) {
        const carry = data[yday].filter((t) => !t.done).map((t) => ({ ...t, done: false }));
        if (carry.length) {
          data[getToday()] = [...(data[getToday()] || []), ...carry];
          setTasks({ ...data });
          localStorage.setItem("studyplanner-tasks", JSON.stringify(data));
        }
      }
      localStorage.setItem("studyplanner-carry", getToday());
    }
  }, []);

  // Save to localStorage
  useEffect(() => {
    localStorage.setItem("studyplanner-tasks", JSON.stringify(tasks));
  }, [tasks]);

  const addTask = (e) => {
    e.preventDefault();
    if (!form.subject || !form.topic) return;
    const newTask = {
      ...form,
      done: false,
      id: Date.now() + Math.random(),
    };
    setTasks((prev) => ({
      ...prev,
      [selectedDay]: [...(prev[selectedDay] || []), newTask],
    }));
    setForm({ subject: "", topic: "", priority: "medium" });
  };

  const toggleDone = (id) => {
    setTasks((prev) => ({
      ...prev,
      [selectedDay]: prev[selectedDay].map((t) =>
        t.id === id ? { ...t, done: !t.done } : t
      ),
    }));
  };

  const deleteTask = (id) => {
    setTasks((prev) => ({
      ...prev,
      [selectedDay]: prev[selectedDay].filter((t) => t.id !== id),
    }));
  };

  const weekDates = getWeekDates();

  return (
    <div className="studyplanner-container">
      <h2>Daily Study Planner</h2>
      <div className="week-nav">
        {weekDates.map((date) => (
          <button
            key={date}
            className={date === selectedDay ? "active" : ""}
            onClick={() => setSelectedDay(date)}
          >
            {new Date(date).toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" })}
          </button>
        ))}
      </div>
      <form className="add-task-form" onSubmit={addTask}>
        <input
          type="text"
          placeholder="Subject"
          value={form.subject}
          onChange={(e) => setForm({ ...form, subject: e.target.value })}
          required
        />
        <input
          type="text"
          placeholder="Chapter/Topic"
          value={form.topic}
          onChange={(e) => setForm({ ...form, topic: e.target.value })}
          required
        />
        <select
          value={form.priority}
          onChange={(e) => setForm({ ...form, priority: e.target.value })}
        >
          {priorities.map((p) => (
            <option key={p.value} value={p.value}>{p.label}</option>
          ))}
        </select>
        <button type="submit">Add</button>
      </form>
      <ul className="task-list">
        {(tasks[selectedDay] || []).length === 0 && (
          <li className="empty">No tasks for this day.</li>
        )}
        {(tasks[selectedDay] || []).map((task) => (
          <li key={task.id} className={task.done ? "done" : ""}>
            <label>
              <input
                type="checkbox"
                checked={task.done}
                onChange={() => toggleDone(task.id)}
              />
              <span className="task-main">
                <span className="subject">{task.subject}</span>
                <span className="topic">{task.topic}</span>
              </span>
              <span className={`priority ${task.priority}`}>{task.priority}</span>
            </label>
            <button className="delete-btn" onClick={() => deleteTask(task.id)}>✕</button>
          </li>
        ))}
      </ul>
    </div>
  );
}