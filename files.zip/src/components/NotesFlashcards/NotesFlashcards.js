import React, { useState, useEffect, useRef } from "react";
import "./NotesFlashcards.css";

function getSavedNotes() {
  return JSON.parse(localStorage.getItem("studypilot-notes") || "[]");
}
function saveNotes(notes) {
  localStorage.setItem("studypilot-notes", JSON.stringify(notes));
}

export default function NotesFlashcards() {
  const [notes, setNotes] = useState(getSavedNotes());
  const [form, setForm] = useState({ subject: "", title: "", content: "", tags: "", bookmark: false });
  const [editingId, setEditingId] = useState(null);
  const [search, setSearch] = useState("");
  const [showFlashcard, setShowFlashcard] = useState(null);
  const pdfRef = useRef();

  useEffect(() => {
    saveNotes(notes);
  }, [notes]);

  // Add or edit note
  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.title || !form.content) return;
    if (editingId !== null) {
      setNotes(notes.map((n) => (n.id === editingId ? { ...form, id: editingId } : n)));
      setEditingId(null);
    } else {
      setNotes([{ ...form, id: Date.now() + Math.random() }, ...notes]);
    }
    setForm({ subject: "", title: "", content: "", tags: "", bookmark: false });
  };

  // Edit a note
  const handleEdit = (note) => {
    setForm(note);
    setEditingId(note.id);
    window.scrollTo(0, 0);
  };

  // Delete a note
  const handleDelete = (id) => setNotes(notes.filter((n) => n.id !== id));

  // Toggle bookmark
  const toggleBookmark = (id) =>
    setNotes(notes.map((n) => (n.id === id ? { ...n, bookmark: !n.bookmark } : n)));

  // Search logic
  const filteredNotes = notes.filter((n) =>
    n.title.toLowerCase().includes(search.toLowerCase()) ||
    n.content.toLowerCase().includes(search.toLowerCase()) ||
    n.subject.toLowerCase().includes(search.toLowerCase()) ||
    (n.tags || "").toLowerCase().includes(search.toLowerCase())
  );

  // Export to PDF (uses browser print dialog as MVP)
  const exportPDF = (note) => {
    setShowFlashcard(null);
    setTimeout(() => {
      const win = window.open("", "PrintWindow");
      win.document.write(`<html><head><title>${note.title}</title></head><body>`);
      win.document.write(`<h2>${note.title}</h2>`);
      win.document.write(`<h4>Subject: ${note.subject}</h4>`);
      win.document.write(`<div>${note.content.replace(/\n/g, "<br/>")}</div>`);
      win.document.write(`<hr/><p>Tags: ${note.tags || ""}</p>`);
      win.document.write("</body></html>");
      win.document.close();
      win.focus();
      win.print();
    }, 100);
  };

  // Flashcard rendering
  const currentFlash = showFlashcard != null ? filteredNotes[showFlashcard] : null;

  return (
    <div className="notesflashcards-container">
      <h2>Notes & Flashcards</h2>
      <form className="note-form" onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Subject"
          value={form.subject}
          onChange={(e) => setForm({ ...form, subject: e.target.value })}
        />
        <input
          type="text"
          placeholder="Title"
          value={form.title}
          required
          onChange={(e) => setForm({ ...form, title: e.target.value })}
        />
        <textarea
          placeholder="Write your note (supports basic formatting)"
          value={form.content}
          required
          onChange={(e) => setForm({ ...form, content: e.target.value })}
          rows={4}
        />
        <input
          type="text"
          placeholder="Tags (comma separated)"
          value={form.tags}
          onChange={(e) => setForm({ ...form, tags: e.target.value })}
        />
        <label>
          <input
            type="checkbox"
            checked={form.bookmark}
            onChange={(e) => setForm({ ...form, bookmark: e.target.checked })}
          />
          Bookmark
        </label>
        <button type="submit">{editingId ? "Update Note" : "Add Note"}</button>
      </form>
      <div className="search-notes">
        <input
          type="text"
          placeholder="Search notes by keyword or tag"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <button onClick={() => setShowFlashcard(0)} disabled={!filteredNotes.length}>
          Flashcard Mode
        </button>
      </div>
      <ul className="note-list">
        {filteredNotes.length === 0 && <li className="empty">No notes found.</li>}
        {filteredNotes.map((note) => (
          <li key={note.id} className={note.bookmark ? "bookmarked" : ""}>
            <div>
              <div className="note-head">
                <span className="note-title">{note.title}</span>
                <span className="note-subject">{note.subject}</span>
              </div>
              <div className="note-content">{note.content.slice(0, 100)}{note.content.length > 100 && "..."}</div>
              <div className="note-tags">{note.tags && note.tags.split(",").map((t, i) => (
                <span className="tag" key={i}>{t.trim()}</span>
              ))}</div>
            </div>
            <div className="note-actions">
              <button onClick={() => handleEdit(note)}>Edit</button>
              <button onClick={() => handleDelete(note.id)}>Delete</button>
              <button onClick={() => toggleBookmark(note.id)}>
                {note.bookmark ? "★" : "☆"}
              </button>
              <button onClick={() => exportPDF(note)}>Export PDF</button>
            </div>
          </li>
        ))}
      </ul>
      {showFlashcard != null && (
        <div className="flashcard-modal">
          <div className="flashcard">
            <div className="flashcard-front">
              <h3>{currentFlash.title}</h3>
              <h5>{currentFlash.subject}</h5>
              <div className="flashcard-content">{currentFlash.content}</div>
              <div className="flashcard-tags">{currentFlash.tags}</div>
            </div>
            <div className="flashcard-controls">
              <button
                onClick={() =>
                  setShowFlashcard(
                    showFlashcard > 0 ? showFlashcard - 1 : filteredNotes.length - 1
                  )
                }
              >
                ◀ Prev
              </button>
              <button onClick={() => setShowFlashcard(null)}>Exit</button>
              <button
                onClick={() =>
                  setShowFlashcard(
                    showFlashcard < filteredNotes.length - 1 ? showFlashcard + 1 : 0
                  )
                }
              >
                Next ▶
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}