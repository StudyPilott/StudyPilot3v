import React from "react";
import PomodoroTimer from "./components/PomodoroTimer/PomodoroTimer";
import StudyPlanner from "./components/StudyPlanner/StudyPlanner";
import JokeGenerator from "./components/JokeGenerator/JokeGenerator";
import NotesFlashcards from "./components/NotesFlashcards/NotesFlashcards";
import ExamReminders from "./components/ExamReminders/ExamReminders";
import "./App.css";

function App() {
  return (
    <>
      <header>📚 StudyPilot</header>
      <main>
        <PomodoroTimer />
        <StudyPlanner />
        <NotesFlashcards />
        <ExamReminders />
        <JokeGenerator />
      </main>
      <footer>© {new Date().getFullYear()} StudyPilot. All rights reserved.</footer>
    </>
  );
}

export default App;